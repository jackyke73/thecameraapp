//
//  BoyfriendCameraTests.swift
//  BoyfriendCameraTests
//
//  Created by 柯杰 on 11/19/25.
//

import Testing

struct BoyfriendCameraTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
